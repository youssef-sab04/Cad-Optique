package cad.project.repositries;

import cad.project.model.Devis;
import cad.project.model.SalesOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DevisRepositry extends JpaRepository<Devis, Long> {
}
