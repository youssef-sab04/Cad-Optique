package cad.project.repositries;

import cad.project.model.Produit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProduitRepositry extends JpaRepository<Produit, Long> {
    Page<Produit> findAll(Specification<Produit> spec, Pageable pageDetails);

}
