package cad.project.repositries;

import cad.project.model.Commande;
import cad.project.model.SalesOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleOrderRepositry extends JpaRepository<SalesOrder, Long> {
}
