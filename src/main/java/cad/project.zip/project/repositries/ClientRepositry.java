package cad.project.repositries;

import cad.project.model.Client;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepositry extends JpaRepository<Client, Long> {
    Page<Client> findAll(Specification<Client> spec, Pageable pageDetails);

}
