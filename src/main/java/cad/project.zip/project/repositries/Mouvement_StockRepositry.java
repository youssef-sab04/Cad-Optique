package cad.project.repositries;

import cad.project.model.Mouvement_Stock;
import cad.project.model.Produit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Mouvement_StockRepositry extends JpaRepository<Mouvement_Stock, Long> {

    Page<Mouvement_Stock> findAllByProduit(Produit produit, Pageable pageDetails);
}
